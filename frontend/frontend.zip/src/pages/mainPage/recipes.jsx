const recipes = [
    {
        image:"https://imagesvc.meredithcorp.io/v3/mm/image?url=https%3A%2F%2Fstatic.onecms.io%2Fwp-content%2Fuploads%2Fsites%2F43%2F2021%2F02%2F03%2F278329-italian-polenta-casserole-2000.jpg&q=85",
        title:"Italian Polenta Casserole",
        link:"https://www.allrecipes.com/recipe/278329/italian-polenta-casserole/",
        by:"Kim's Cooking Now"
    },
    {
        image:"https://imagesvc.meredithcorp.io/v3/mm/image?url=https%3A%2F%2Fimages.media-allrecipes.com%2Fuserphotos%2F9402463.jpg&q=85",
        title:"Caramel Apple Bundt® Cake",
        link:"https://www.allrecipes.com/recipe/285641/caramel-apple-bundt-cake/",
        by:"Kim"
    },
    {
        image:"https://imagesvc.meredithcorp.io/v3/mm/image?url=https%3A%2F%2Fimages.media-allrecipes.com%2Fuserphotos%2F8597386.jpg&q=85",
        title:"Basmati Rice and Turkey Stuffed Peppers",
        link:"https://www.allrecipes.com/recipe/270756/basmati-rice-and-turkey-stuffed-peppers/",
        by:"Emily Ott"
    },
    {
        image:"https://imagesvc.meredithcorp.io/v3/mm/image?url=https%3A%2F%2Fimages.media-allrecipes.com%2Fuserphotos%2F4340194.jpg&w=596&h=596&c=sc&poi=face&q=85",
        title:"Carne Asada Breakfast Burrito",
        link:"https://www.allrecipes.com/recipe/256301/carne-asada-breakfast-burrito/",
        by:"CoOkInGnUt"
    },
        {
        image:"https://imagesvc.meredithcorp.io/v3/mm/image?url=https%3A%2F%2Fimages.media-allrecipes.com%2Fuserphotos%2F1098038.jpg&q=85",
        title:"Anne's Chicken Chilaquiles Rojas",
        link:"https://www.allrecipes.com/recipe/279677/annes-chicken-chilaquiles-rojas/",
        by:"Dylan's Nana"
    },
]

export default recipes;