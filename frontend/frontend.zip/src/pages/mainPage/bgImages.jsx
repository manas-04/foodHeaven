const Images = [
    "https://images.food52.com/LBx5TvV-ghDLfquXJ4cuTSqiPwU=/660x440/filters:format(webp)/14b4a731-fa45-42fe-b159-8d577c94d65c--2015-0217_kale-macaroni-and-cheese_bobbi-lin-7575.jpg",
    "https://images.food52.com/Qg-6uHA85OyIrWSYPpumw0x8XVM=/660x440/filters:format(webp)/dc712ebb-0d3f-44d7-916c-a09d3cbfe9b5--2019-1001_russian-cabbage-pie_3x2_julia-gartland_382.jpg",
    "https://images.food52.com/VDgQqa8pVlwm4ZIJrYV_8jrM0p8=/660x440/filters:format(webp)/244098bb-1d15-4799-84f7-4d477092e32e--2019-0723_worlds-best-cake-banana-coconut_3x2_rocky-luten_042.jpg",
];

export default Images;