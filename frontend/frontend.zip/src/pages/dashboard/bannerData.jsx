 const images = [
    {
      label: 'Burgers so good you will come back again and again',
      imgPath:
        'https://images.pexels.com/photos/2983098/pexels-photo-2983098.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
      recipePath:
        'https://spoonacular.com/tex-mex-burger-663050'
    },
    {
      label: 'There is always time for some Tea and Samosa',
      imgPath:
        'https://images.pexels.com/photos/2474658/pexels-photo-2474658.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
        recipePath:
        'https://spoonacular.com/baked-indian-samosas-633650'
    },
    {
      label: 'Cravings can never be stopped without noodles',
      imgPath:
       'https://images.pexels.com/photos/2347311/pexels-photo-2347311.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
       recipePath:
       'https://spoonacular.com/asian-noodles-632854'
    },
    {
      label: 'I could just have chips and salsa for dinner every day.',
      imgPath:
        'https://www.femmefiestaclub.com/wp-content/uploads/2019/07/shutterstock_294979184.jpg?auto=format&fit=crop&w=400&h=250&q=60',
        recipePath:
        'https://spoonacular.com/salsa-715870'
    },
  ];

  export default images;